//=sebcus the comment insertion system is floored and puts comments in odd places.
// until this is fixed, better to not add them back in
//$this->append(array("comment", $m[1]));

Haven't done this with latest version. It may be fine with the comments.

